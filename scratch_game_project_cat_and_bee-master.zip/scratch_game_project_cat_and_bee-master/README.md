# scratch_game_project_cat_and_bee
This is a simple game using inuilt sprites from scratch.
